Advanced commands to develop on the forge and the benchmark.
Stability not guaranteed.
